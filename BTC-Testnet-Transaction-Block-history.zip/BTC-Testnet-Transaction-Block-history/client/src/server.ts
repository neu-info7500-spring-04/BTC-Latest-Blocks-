const http = require('http');
const express = require('express');
const { request } = require('graphql-request');
const { ApolloServer, gql } = require('apollo-server-express');

const app = express();

// GraphQL Schema
const typeDefs = gql`
  type Block {
    height: Int
    timestamp: String
    transactionCount: Int
    blockSize: Int
    blockWeight: Int
  }

  type Query {
    blocks(limit: Int): [Block]
  }
`;

// Resolver
const resolvers = {
  Query: {
    blocks: async (_parent, { limit }) => {
      const query = `{
        bitcoin {
          blocks(options: {desc: ["height"], limit: ${limit || 10}}) {
            height
            timestamp {
              time(format: "%Y-%m-%d %H:%M:%S")
            }
            transactionCount
            blockSize
            blockWeight
          }
        }
      }`;

      try {
        const response = await request('https://graphql.bitquery.io/', query);
        return response.bitcoin.blocks;
      } catch (error) {
        console.error('Error fetching data from Bitquery API:', error);
        return [];
      }
    },
  },
};

const server = new ApolloServer({ typeDefs, resolvers });
server.applyMiddleware({ app });

const httpServer = http.createServer(app);

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
s