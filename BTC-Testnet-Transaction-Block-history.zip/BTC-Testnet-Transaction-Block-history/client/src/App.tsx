// src/App.tsx
import React from 'react';
import { ApolloClient, InMemoryCache, ApolloProvider, gql, useQuery } from '@apollo/client';

// 创建 Apollo 客户端
const client = new ApolloClient({
  uri: 'http://localhost:4000/graphql', // 注意这里的端口号与后端服务器一致
  cache: new InMemoryCache(),
});

// GraphQL 查询
const GET_BLOCKS = gql`
  query GetBlocks {
    blocks(limit: 10) {
      height
      timestamp
      transactionCount
      blockSize
      blockWeight
    }
  }
`;

const App: React.FC = () => {
  const { loading, error, data } = useQuery(GET_BLOCKS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :(</p>;

  return (
    <div>
      <h1>Bitcoin Blockchain Blocks</h1>
      <ul>
        {data.blocks.map((block: any) => (
          <li key={block.height}>
            Height: {block.height}, Timestamp: {block.timestamp}, Transaction Count: {block.transactionCount}, Block Size: {block.blockSize}, Block Weight: {block.blockWeight}
          </li>
        ))}
      </ul>
    </div>
  );
};

const AppWithApolloProvider: React.FC = () => {
  return (
    <ApolloProvider client={client}>
      <App />
    </ApolloProvider>
  );
};

export default AppWithApolloProvider;
