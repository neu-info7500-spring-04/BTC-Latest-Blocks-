// src/Header.tsx
import './index.css'


function Header(){
  return (
    <div className="app-container">


    <header>
      <h1>Welcome to Transaction History of Hash Id:</h1>
    </header>
    </div>
  );
}

export default Header;
